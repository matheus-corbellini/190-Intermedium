export const PATHS = {
  HOME: "/",
  LOGIN: "/login",
  REGISTER: "/register",
};
