export interface Area {
  id: string;
  name: string;
  description: string;
}
